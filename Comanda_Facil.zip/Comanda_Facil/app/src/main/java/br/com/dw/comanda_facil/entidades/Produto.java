package br.com.dw.comanda_facil.entidades;

import com.j256.ormlite.field.DataType;
import com.j256.ormlite.field.DatabaseField;
import com.j256.ormlite.table.DatabaseTable;

@DatabaseTable(tableName = "tbproduto")
public class Produto {

    @DatabaseField(generatedId = true)
    private Integer id;
    @DatabaseField
    private String descricao;
    @DatabaseField
    private double valor;
    @DatabaseField
    private String ean;
    @DatabaseField(dataType = DataType.BOOLEAN)
    private boolean status;
    @DatabaseField(dataType= DataType.BYTE_ARRAY)
    private byte[] imagem;


    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public boolean isStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public double getValor() {
        return valor;
    }

    public void setValor(double valor) {
        this.valor = valor;
    }

    public String getEan() {
        return ean;
    }

    public void setEan(String ean) {
        this.ean = ean;
    }

    public byte[] getImagem() {
        return imagem;
    }

    public void setImagem(byte[] imagem) {
        this.imagem = imagem;
    }
}
